#Proxy Settings
[System.Net.WebRequest]::DefaultWebProxy = [System.Net.WebRequest]::GetSystemWebProxy()
[System.Net.WebRequest]::DefaultWebProxy.Credentials = [System.Net.CredentialCache]::DefaultNetworkCredentials

#Create Function
Function Add-APIData ($server, $database, $text)
{
    $scon = New-Object System.Data.SqlClient.SqlConnection
    $scon.ConnectionString = "SERVER=$server;DATABASE=$database;Integrated Security=True;Trusted_connection=true"

    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $cmd.Connection = $scon
    $cmd.CommandText = $text
    $cmd.CommandTimeout = 0

    $scon.Open()
    $cmd.ExecuteNonQuery()
    $scon.Close()
    $cmd.Dispose()
    $scon.Dispose()
}

#  Retrieve JSON data by API
$api_key = "6571bfd674516675f3abd416c99e8d60"
[string]$webstring = "https://api.stlouisfed.org/fred/series/observations?series_id=WPU057&api_key=6571bfd674516675f3abd416c99e8d60&file_type=json"
$webget = New-Object System.Net.WebClient
$result = $webget.DownloadString($webstring)

#pass JSON to variable
$result = ConvertFrom-Json $result
$add = @()

#Pass data to SQL Stmt !!!!Must have created table already
foreach ($r in $result.observations)
{
        $add += "INSERT INTO WPU057 VALUES ('" + $r.date + "','" + $r.value + "')" + $nl
}

#Data Validation
if ($r.value -ne ".")  #looking for bad characters
{
 $add += "INSERT INTO WPU057 VALUES ('" + $r.date + "','" + $r.value + "')" + $nl
}

#Add data to SQL db
Add-APIData -server ".\SQLEXPRESS" -database "TEST" -text $add  #ANWT22561\SQLEXPRESS

#####SSMS Script#####
#View results in SQL SERVER
#SELECT *
#FROM TEST.dbo.tb_FRED_WTI
#ORDER BY WTIDate









# database Intraction

$SQLServer = "ANWT22651\SQLEXPRESS" #use Server\Instance for named SQL instances!
$SQLDBName = "TEST"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Server = $SQLServer; Database = $SQLDBName; 
User ID= YourUserID; Password= YourPassword" 
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = 'dbo.testSproc'
$SqlCmd.Connection = $SqlConnection 
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$SqlAdapter.SelectCommand = $SqlCmd 
$DataSet = New-Object System.Data.DataSet
$SqlAdapter.Fill($DataSet) 
$SqlConnection.Close() 

#End :database Intraction
clear